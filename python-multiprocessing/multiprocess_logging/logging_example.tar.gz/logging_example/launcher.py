#! /usr/bin/python

import sys
import os
import logging
import atexit
import argparse
import time
import signal
import copy
import json
import random
import time
from multiprocessing.pool import Pool
import multiprocessing
from collections import defaultdict


log_m = logging.getLogger(__name__)


def printBanner():
    log_m.info("Welcome!!!" 
             .center(BANNER_WIDTH))

# Handle signal terminate to kill test gracefully
def handlesignal(signum, frame):
    raise KeyboardInterrupt()

class TestGroupError(Exception):
    pass

def scanESXs(hosts):
    return [ESXHandler(host) for host in hosts]

def deepcopyESX(esx, drv, hba, dev, runtime):
    esx_copy = copy.deepcopy(esx)
    for attr in ['vmhba2driver', 'device2RuntimeNm', 'device2vmhba',\
                 'driver2vmhba', 'driver2vmnic', 'driver_interface',\
                 'vmhba2device', 'vmhba2vmnic', 'vmhbas',\
                 'vmnic2vmhba']:
        getattr(esx_copy, attr).clear()
    esx_copy.vmhba2driver[hba] = drv
    esx_copy.device2RuntimeNm[dev] = runtime
    esx_copy.device2vmhba[dev] = [hba]
    esx_copy.driver2vmhba[drv] = [hba]
    esx_copy.driver_interface[drv] = esx.driver_interface[drv]
    esx_copy.vmhba2device[hba] = [dev]
    esx_copy.vmhbas = {hba:copy.deepcopy(esx.vmhbas[hba])}
    return esx_copy

def updateESXs(esxs):
    ret = []
    for esx in esxs:
        for drv in esx.driver2vmhba.keys():
            # skip the vmklinux driver here
            if not esx.isNativeDriver(drv):
                continue
            for hba in esx.driver2vmhba[drv]:
                for dev in esx.vmhba2device[hba]:
                    runtime = esx.device2RuntimeNm[dev]
                    if esx.GetLunSize(dev) >= 1024 * 20 and runtime:
                       esx_copy = deepcopyESX(esx, drv, hba, dev, runtime)
                       ret.append([esx_copy, drv, hba, dev, runtime])
    return ret

def createCaseLogFolder(logfolder, drv, dev, testid):
    folder = os.path.join(logfolder, '%s-%s-%s' % (drv, dev, testid))
    if not os.access(folder, os.F_OK):
        os.makedirs(folder)
    return folder

def deepcopyConsCheck(con, esx, drv, hba, dev):
    con_copy = copy.copy(con)
    con_copy.esxHandlers = {esx:[drv]}
    con_copy.esxHandler = esx
    con_copy.drivers = [drv]
    con_copy.vmhbas = [hba]
    con_copy.devices = [dev]
    return con_copy

def getConsCheck(con):
    tested_devices = {}
    esx_list = updateESXs(con.esxHandlers.keys())
    boot_dev = ''
    for esx, drv, hba, dev, runtime in esx_list: 
        if not boot_dev:
            _, boot_dev = esx.GetBootDevice()
        con_copy = deepcopyConsCheck(con, esx, drv, hba, dev)
        device_info = { 'vmhba': hba,
                        'driver': drv,
                        'device': dev,
                        'conscheck': con_copy,
                        'israwdisk': esx.isRawDisk(dev),
                        'isbootbank': dev == boot_dev,
                        }
        tested_devices[dev] = device_info
    return tested_devices


def getTestCases(test_ids, tested_devices, input_drvs=None):
    drvs = []
    skip_tc = {}
    drv_tc = {}
    for k, v in tested_devices.items():
        if v['driver'] not in drvs:
            drvs.append(v['driver'])
    if not input_drvs:
        drvs = list(set(drvs) & set(input_drvs))
    for drv in drvs:
        drv_tc[drv] = []
        for tc in test_ids:
            if drv in tc['validDrivers']:
                drv_tc[drv].append(tc)
                continue
            if drv not in skip_tc:
                skip_tc[drv] = []
            skip_tc[drv].append(tc['TestID'])
    return drv_tc, skip_tc

def getTestFromJson(json_file='', group='HPTC-LS_NoVM', test_ids=None):
    if group and test_ids:
        raise TestGroupError('Not support both parameters test group and test select.')
    with open(json_file) as f: 
        groups, test_cases = json.load(f)
    if test_ids is None:
        try:
            test_ids = groups[group]
        except KeyError:
            raise TestGroupError('Invalid group name: %s. Valid groups are %s' % (group, ', '.join(groups)))
    test_ids_lower = [id.lower() for id in test_ids if 'SMART' not in id]
    retval = [val for id, val in test_cases.items() if id in test_ids_lower]
    return retval

def mapDriverDevice(t_devs):
    drv2dev = {}
    for k, v in t_devs.items():
        if v['driver'] not in drv2dev:
            drv2dev[v['driver']] = [k]
            continue
        drv2dev[v['driver']].append(k)
    dev2drv = {}
    for k, v in drv2dev.items():
        for dev in v:
            dev2drv[dev] = k
    return drv2dev, dev2drv

def initJobQ(num, devList, drv2dev, dev2drv):
    drvs = list(drv2dev.keys())
    devs = list(dev2drv.keys())
    removed = set()
    tested = set()
    rest_drv = set()
    rest_devList = []
    i = 0
    while True:
        if len(removed) == len(drvs):
            break
        drv = drvs[i%len(drvs)]
        i += 1
        if len(drv2dev[drv]) == 0:
            removed.add(drv)
            continue
        dev = random.choice(drv2dev[drv])
        drv2dev[drv].remove(dev)
        devList.append([drv, dev, []])
        tested.add(drv)
        if len(devList) == devs:
            break
        if len(devList) == num:
            break
    for drv in removed:
        drvs.remove(drv)
    rest_drv = set(drvs) - tested
    if rest_drv:
        for drv in rest_drv:
            if len(drv2dev[drv]) == 0:
                continue
            dev = random.choice(drv2dev[drv])
            drv2dev[drv].remove(dev)
            rest_devList.append([drv, dev, []])
    return rest_devList


def configCase(con, item, tc_id, t_devs, logfolder):
    drv, dev = item
    if con.getTestInfo(tc_id) and con.checkDriver():
        con.masterDir = createCaseLogFolder(logfolder, drv, dev, tc_id)
        return True
    return False

def schedule(testcases):
    run_level_a = ['Functional::NoVM_DriverLoadUnload',
                   'Functional::NoVM_Device']
    run_level_b = ['Functional::NoVM_VMFS',
                   'Functional::NoVM_Reboot']
    setup_type = ['LS_Setup_RawDisk',
                  'LS_Setup_NoVM',
                  'LS_Setup_VC-PersistentVM']
    for tp in setup_type:
        for tc in testcases:
            if tc['TestID'] in run_level_a or tc['TestID'] in run_level_b:
                continue
            if tp in tc['SetupType']:
                return tc, 0
    if testcases:
        for tc in testcases:
            if tc['TestID'] in run_level_a:
                return tc, 1
            if tc['TestID'] in run_level_b:
                return tc, 2
    return random.choice(testcases), 2

def fill_data(q, drv, dev, tc, level, caseQ, level_a, level_b):
    if level == 0:
        caseQ[q].append([drv, dev, tc['TestID'], tc['SetupType'], None, None])
    elif level == 1:
        level_a[drv].append([drv, dev, tc['TestID'], tc['SetupType'], None, None])
    elif level == 2:
        level_b[drv].append([drv, dev, tc['TestID'], tc['SetupType'], None, None])
    else:
        log_m.error('failed to assign case %s' % str(tc))

def picker(q, running_tc, caseQ, level_a):
    """
    return (drv, dev, tc_id, tc_type, skip_setup, skip_cleanup)
    """
    if caseQ[q]:
        return caseQ[q].pop(0)
    if level_a:
        rest_drv = set()
        for key, val in caseQ.items():
            if not val:
                continue
            for drv, *_ in val:
                rest_drv.add(drv)
        for key, val in running_tc.items():
            if not val:
                continue
            drv, *_ = val
            rest_drv.add(drv)
        drvs_a = set(list(level_a.keys()))
        diff = drvs_a - rest_drv
        if not diff:
            return [', '.join(rest_drv), None, None, None, None, None]
        next_drv = random.choice(list(diff))
        item = level_a[next_drv].pop(0)
        if not level_a[next_drv]:
            level_a.pop(next_drv)
        return item
    if level_b:
        for key, val in running_tc.items():
            if val:
                return [None, None, None, None, None, None]
        drvs_b = list(level_b.keys())
        for drv in drvs_b:
            if not level_b[drv]:
                level_b.pop(drv)
                continue
            item = level_b[drv].pop(0)
            return item
    return []

def allocator(drv_tc, inQList, devList, rest_devList, drv2dev, dev2drv):
    caseQ = { q:[] for q in inQList }
    level_a = defaultdict(list)
    level_b = defaultdict(list)
    total = []
    # [(drv, dev, casename, setup type, skip setup, skip clean up), ...]
    if len(devList) != len(inQList):
       log_m.error('len(devList) != len(inQList)  !!!')
       sys.exit(1)
    if rest_devList or len(drv_tc.keys()) == len(inQList):
        while True:
            q = inQList.pop(0)
            inQList.append(q)
            if devList:
                drv, dev, _ = devList.pop(0)
            elif rest_devList:
                drv, dev, _ = rest_devList.pop(0)
            else:
                break
            while drv_tc[drv]:
                tc, level = schedule(drv_tc[drv])
                fill_data(q, drv, dev, tc, level, caseQ, level_a, level_b)
                drv_tc[drv].remove(tc)
            drv_tc.pop(drv)
            total.append([drv, dev, []])
    else:
        i = 0
        same = {}
        devs = [dev for _, dev, _ in devList]
        dev2q = {}
        drvs = list(drv2dev.keys()) 
        for drv, dev, _ in devList:
            if i == len(inQList):
                break
            if drv not in same:
                same[drv] = [inQList[i]]
                i += 1
                continue
            same[drv].append(inQList[i])
            i += 1
        i = 0
        for _, dev, _ in devList:
            if i == len(inQList):
                break
            dev2q[dev] = inQList[i]
            i += 1
        remove = []
        while drv_tc:
            drv, dev, _ = devList.pop(0)
            devList.append([drv, dev, []])
            if drv in remove:
                continue
            q = dev2q[dev]
            tc, level = schedule(drv_tc[drv])
            fill_data(q, drv, dev, tc, level, caseQ, level_a, level_b)
            drv_tc[drv].remove(tc)
            if not drv_tc[drv]:
                drv_tc.pop(drv)
                remove.append(drv)
    return caseQ, level_a, level_b, total

def group(all):
    for val in all:
        n = len(val)
        if n == 0:
            continue
        val[0][4] = False
        if n == 1:
            val[0][5] = False
            continue
        for i in range(n - 1):
            if val[i][3] == val[i + 1][3]:
                val[i][5] = True
                val[i + 1][4] = True
            else:
                val[i][5] = False
                val[i + 1][4] = False
        val[n - 1][5] = False

def configSetup(caseQ):
    for key, value in caseQ.items():
        if not value:
            continue
        drv, *_ = value[0] 
        i = 0
        all = [[]]
        for c in value:
            if drv != c[0]:
                all.append([])
                drv = c[0]
            all[-1].append(c)
        group(all)
        value = [v for val in all for v in val ]

def checkHost(esx):
    timeout = 900
    start = time.time()
    while time.time() - start < timeout:
       if not ping(esx.hostname):
           log_m.debug('%s is offline' % esx.hostname)
           time.sleep(10)
       else:
           if esx.remote.StafPing():
               log_m.debug('%s is online, staf is online' % esx.hostname)
               return True
           log_m.debug('%s is online, staf is not online' % esx.hostname)
           time.sleep(1)
    log_m.error('After 600 seconds waiting, %s is offline, staf is offline' % esx.hostname)
    return False

def runFunc(job):
    try:
        TestCaseResults = {TEST_CLEANUP: ReVal.PASSED, }
        con, bindir, *_ = job
        # here create logger for each processer
        log = logging.getLogger(__name__)
        setup_logging(os.path.join(bindir, 'logging_sub.json'), con.masterDir)
        printBanner()
        log.info('Setting logs folder: %s' % con.masterDir) 
        moduleToTestHandle = { 'network': NetworkingHandler,
                               'storage': StorageHandler,
                              }
        chosen_handler = moduleToTestHandle.get(con.ioType, TestHandler)
        #axxxxx
        myTest = chosen_handler(con)
        try:
            myTest.Setup()
            if not myTest.ConfigTest():
                raise EnvironmentError('Failed to Configure Test')
        except SkipConfigure:
            pass
      
        # If you are here means Setup or config was done successfully
        log.info(SETUP_MSG)
      
        padding = 15
        test_str_len = padding + len(con.testId)
        log.info("*" * test_str_len)
        log.info("Starting Test %s" % con.testId)
        log.info("*" * test_str_len)
      
        testFunc = getattr(myTest, con.testfunc)
        exit_status = testFunc()
        TestCaseResults[TEST_CLEANUP] = myTest.Cleanup(exit_status)
        TestCaseResults[con.testId] = exit_status
        con.createSummaryReport(TestCaseResults)
    except CustomExitError as e:
        log.error(e)
        exit_status = e.exit_status
    except LogicExit as e:
        log.error(e)
        exit_status = ReVal.FAILED
        myTest.Cleanup(exit_status)
    except Exception as e:
        exit_status = ReVal.SCRIPT_ERROR
        log.error('Test ran into exception', exc_info=True)
        log.error(e)
        if myTest:
            if not ping(myTest.esxhost.hostname):
                print('Failed to ping %s. Check server for PSOD'
                          % myTest.esxhost.hostname)
                log.error('Failed to ping %s. Check server for PSOD'
                          % myTest.esxhost.hostname)
                exit_status = ReVal.ESX_PSOD
            else:
                myTest.Cleanup(exit_status)
    finally:
        if exit_status == ReVal.PASSED and TestCaseResults[TEST_CLEANUP] != ReVal.PASSED:
            exit_status = ReVal.FAILED
        return exit_status
    

def runJob(inQ, outQ):
    while True:
        job = inQ.get()
        if job == 'stop':
            outQ.put('Done')
            break
        exit_status = runFunc(job)
        time.sleep(300)
        _ = inQ.get()
        outQ.put({'driver':job[2], 'device':job[3], 'testcase':job[0].testId, 'result':exit_status})

def worker(inQList, outQ):
    p = Pool(processes=len(inQList))
    for inQ in inQList: 
        p.apply_async(runJob, args=(inQ, outQ))
    return p


if __name__ == "__main__":
    bindir = os.path.dirname(os.path.abspath(__file__))
    test_parser = ArgParser(os.path.join(bindir, 'Test.json'))
    test_parser.parse_args()
    datestamp = time.strftime('%d-%b-%Y')
    timestamp = time.strftime('%H_%M_%S')

    signal.signal(signal.SIGTERM, handlesignal)
    consCheck, myTest = None, None
    exit_status = ReVal.NOT_RUN
    p = None
    inQList= None
    atexit.register(STAFRemote.destroyHandles)

    esxs = scanESXs(test_parser.args['hosts'])
    esxs_list = updateESXs(esxs)

    try:
        logfolder = create_log_folder(test_parser.args, datestamp, timestamp)
        setup_logging(os.path.join(bindir, 'logging.json'), logfolder)
        StackHandler.PRINT_STACK = test_parser.args['print_stack']
        printBanner()
        log_m.info('Setting logs folder: %s' % logfolder)

        consCheck = ConsCheck(bindir, test_parser.args, logfolder)


        # SetHostName should be called after consCheck
        # before it calling STAF remote. STAF might not be
        # initialized before ConsCheck
        VmkLogHandler.ENABLED = True

        consCheck.CheckLogDisk(test_parser.args['log_location'])
        consCheck.SyncTime()


        t_devs = getConsCheck(consCheck)
        t_ids = getTestFromJson('Groups.json', group=test_parser.args['testgroup'], test_ids=test_parser.args['testList'])
        drv_tc, skip_tc = getTestCases(t_ids, t_devs, input_drvs=test_parser.args['drivers'])
        total_tc = copy.deepcopy(drv_tc)
        run_tc = {}
        done_tc = {}
        devList = []
        drv2dev, dev2drv = mapDriverDevice(t_devs)

        total_job = consCheck.numJobs
        # limition of the job number is the deivce number
        num = total_job if len(dev2drv) > total_job else len(dev2drv)
        rest_devList = initJobQ(num, devList, drv2dev, dev2drv)
     
        inMg = multiprocessing.Manager()
        outMg = multiprocessing.Manager()
        inQList = [inMg.Queue(maxsize=1) for i in range(num)]
        outQ = outMg.Queue()
        p = worker(inQList, outQ)
        log_m.info('Starting %d workers, will run test cases for drivers %s' % (num, ', '.join(list(drv2dev.keys()))))
        for v, e, _ in devList:
            log_m.info('Starting test on %s:%s' % (v, e))

        caseQ, level_a, level_b, total = allocator(drv_tc, inQList, devList, rest_devList, drv2dev, dev2drv)
        configSetup(caseQ)
        configSetup(level_a)
        configSetup(level_b)
        #log_m.info('caseQ = %s' % str(caseQ))
        finished = 0
        ret = []
        running_tc = { q:() for q in inQList }
        atexit.register(consCheck.createAllSummary, ret, skip_tc, total_tc)
        while True:
            for item in inQList:
                q = item
                if not q.full():
                    next_run = picker(q, running_tc, caseQ, level_a)
                    if not next_run:
                        q.put('stop')
                        continue
                    drv, dev, tc_id, _, skip_setup, skip_cleanup = next_run
                    if not drv:
                        log_m.debug('Still have test cases running on %s, wait the test cases finish, then run level B test cases' % [ val[0] for _, val in running_tc.items() if val])
                        time.sleep(3)
                        continue
                    if not dev:
                        log_m.debug('Still have test cases running on %s, wait the test cases finish, then run level A test cases' % drv)
                        time.sleep(3)
                        continue
                    con = t_devs[dev]['conscheck']
                    if not checkHost(con.esxHandler):
                        pass
                    con.skipSetup = skip_setup
                    con.skipCleanup = skip_cleanup
                    if not configCase(con, (drv, dev), tc_id, t_devs, logfolder):
                        if drv not in skip_tc:
                            skip_tc[drv] = []
                        skip_tc[drv].append(tc_id)
                        continue
                    if 'DriverLoadUnload' in tc_id:
                        esx = copy.deepcopy(con.esxHandler)
                        tmp_con = copy.copy(con)
                        tmp_con.esxHandler = esx
                        con = tmp_con
                    run = (con, bindir, drv, dev)
                    log_m.info('Driver %s: Starting %s on device %s' % (drv, tc_id, dev))
                    q.put(run)
                    running_tc[q] = (drv, dev, tc_id)
                    time.sleep(3)
                    q.put(0)
                time.sleep(1)
            while not outQ.empty():
                result = outQ.get()
                if result == 'Done':
                    finished += 1
                    continue
                ret.append(result)
                for key, val in running_tc.items():
                    log_m.debug('key = %s, val = %s' % (key, str(val)))
                    if not val:
                        continue
                    if result['driver'] == val[0] and result['device'] == val[1] and result['testcase'] == val[2]:
                        running_tc[key] = ()
                log_m.info('%s: Finished %s on device %s, result: %s' % (result['driver'], result['testcase'], result['device'], ReVal.toString[result['result']]))
            if finished == num:
                break
            time.sleep(1)
        time.sleep(10)

    except CustomExitError as e:
        log_m.error(e)
        exit_status = e.exit_status
    except LogicExit as e:
        log_m.error(e)
        exit_status = ReVal.FAILED
        myTest.Cleanup(exit_status)
    except Exception as e:
        exit_status = ReVal.SCRIPT_ERROR
        log_m.error('Test ran into exception', exc_info=True)
        if myTest:
            if not ping(myTest.esxhost.hostname):
                print('Failed to ping %s. Check server for PSOD'
                          % myTest.esxhost.hostname)
                log_m.error('Failed to ping %s. Check server for PSOD'
                          % myTest.esxhost.hostname)
                exit_status = ReVal.ESX_PSOD
            else:
                myTest.Cleanup(exit_status)
    except KeyboardInterrupt:
        log_m.info('Received keyboard interrupt during test')
        exit_status = ReVal.ABORTED
    finally:
        if consCheck:
            if not checkHost(consCheck.esxHandler):
                pass
            consCheck.esxHandler.cleanUpESX()
            consCheck.dtaas_stop(exit_status)
            if consCheck.serial_logging:
                consCheck.serial_logging.stopSerialCapture()
            if exit_status != ReVal.ESX_PSOD:
                consCheck.StopKernelLog()
        if inQList:
            log_m.info('Try to kill the running jobs...')
            for q in inQList:
                if not q.full():
                    q.put('stop')
        if p:
            p.terminate()
            p.join()
            p.close()
        sys.exit(exit_status)
