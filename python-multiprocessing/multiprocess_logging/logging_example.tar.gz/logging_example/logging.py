import logging, logging.handlers, logging.config
import sys
import os
import time
import json
import inspect
from remotes.STAFRemote import STAFRemote
from lib.Util import get_credentials, ping
from lib.ConnectServ import ConnectServ, ConnectServError

log = logging.getLogger('Logging')

class NoStafFilter(logging.Filter):
    def filter(self, record):
        """
        This function to filter out messages from STAFRemote module
        @param record: record contain name, data, time, messages etc
        @return: True if message should print out
                 False if message should not print out
        """
        return 'STAFRemote' not in record.name


class NoVmDumperFilter(logging.Filter):
    def filter(self, record):
        """
        ignore vmdump message from STAF
        """
        try:
            return 'vmdumper' not in record.msg
        except TypeError:
            # record.msg is not always string. We don't want vmdumper string
            # in staf.log, so it's ok to return true if record.msg is not string
            return True

class StackFilter(logging.Filter):
    def filter(self, record):
        """
        only work on ERROR level
        """
        return 'ERROR' in record.levelname

class StackHandler(logging.Handler):
    PRINT_STACK = False
    # since the handler of the logging module is thread safe, we do not need to
    # add a lock here to lock the I/O output to stack.log for multi-threading
    #
    # recursive to get the inner variables, only recursive 2 times,
    # since some variables are reference each others.
    STACKDEEP = 2
    def __init__(self, filename):
        super().__init__()
        self.filename = filename
        self.stackdeep = 0

    def emit(self, record):
        """
        override emit method in logging.Handler
        """
        def _saveStacktoFile(msg):
            """
            write message to file
            """
            with open(self.filename, 'a+') as fd:
                fd.write(msg)

        def _skipVars(k, v):
            """
            skip variables which we do not want
            """
            if k in bypassVars:
                return True
            if inspect.isclass(v) or inspect.ismodule(v) or inspect.isfunction(v):
                return True
            return False

        def _extendDict(v, num):
            """
            extend the output of dictionary
            """
            try:
                if isinstance(v, dict):
                    return json.dumps(v, indent=4).replace('\n', '\n%s' % ('\t'*num))
            except:
                pass
            return str(v)

        def _getInnerVars(k, v):
            """
            get the inner variables
            """
            msg = ''
            self.stackdeep += 1
            if isinstance(v, classList):
                first_line = 1
                msg += '{0}{1}:\t{2}\n{0}  \-----'.format('\t'*(self.stackdeep - first_line), str(k),
                       _extendDict(v, self.stackdeep - first_line + 1))
                for s_k, s_v in vars(v).items():
                    if _skipVars(s_k, s_v):
                        continue
                    if self.stackdeep < StackHandler.STACKDEEP and isinstance(s_v, classList):
                        msg += _getInnerVars(s_k, s_v)
                    else:
                        msg += '{0}{1}:\t{2}\n'.format('\t'*(0 if first_line else self.stackdeep - first_line),
                               str(s_k), _extendDict(s_v, self.stackdeep - first_line + 1))
                    first_line = 0
                self.stackdeep -= 1
            return msg

        def _getVars(f_vars):
            """
            get the variables
            """
            msg = ''
            for k, v in f_vars.items():
                if _skipVars(k, v):
                    continue
                msg_inner = _getInnerVars(k, v)
                self.stackdeep = 0
                if not msg_inner:
                    msg += "%s:\t%s\n" % (str(k), _extendDict(v, 1))
                    continue
                msg += msg_inner
            return msg

        if StackHandler.PRINT_STACK:
            from drv.CheckHandler import CheckHandler
            classList = (CheckHandler)
            bypassVars = ['__doc__', '__loader__', '__cached__', '__builtins__', '__spec__', 'xmlConfig',
                          'json_testgroups', 'test_group', 'summaryFields', 'hwPCI']
            # ignore all the exceptions
            try:
                msg = "{0}\n{1}Full ERROR Stack\n{0}\n\n\n".format("#"*120, " "*45)
                msg += "{0}\n{1}ERROR Msg\n{0}\n".format("*"*120, " "*50)
                msg += "%s-%s-%s-%s : %s\n\n\n" % (record.asctime, record.levelname, record.name,
                                      record.funcName, record.message)
                _saveStacktoFile(msg)
                i = 1
                callstack = []
                for frame, filename, line_num, func, source_code, source_index in inspect.stack():
                    if 'lib/Logging.py' in filename or 'logging/__init__.py' in filename:
                        continue
                    msg = "{0}\n{1} The stack of {2}() in {3} \n{0}\n".format("*"*120, " "*30, func,
                          os.path.basename(filename))
                    msg += "FILENAME:%s\nLINENO:%s\nFUNCTION:%s\n" % (filename, line_num, func)
                    msg += "{0}\n{1}Global Variables in {2}\n{0}\n".format("-"*120, " "*30,
                           "%s(%s)" % (func, os.path.basename(filename)))
                    # get global variables
                    msg += _getVars(frame.f_globals)
                    msg += "{0}\n{1}Local Variables in {2}\n{0}\n".format("-"*120, " "*30,
                           "%s(%s)" % (func, os.path.basename(filename)))
                    # get local variables
                    msg += _getVars(frame.f_locals)
                    msg += '\n\n\n'
                    _saveStacktoFile(msg)
                    callstack.append('%s(%s):%s' % (func, os.path.basename(filename), str(line_num)))
                    i += 1
                msg = "{0}\n{1} Function Call Stack \n{0}\n".format("*"*120, " "*50)
                msg += ' -> '.join(callstack[::-1])
                msg += '\n\n\n'
                _saveStacktoFile(msg)
            except Exception as e:
                # ignore all the exccption in above block
                # we do not want break the main process at any time.
                log.debug(e, exc_info=True)
                pass

class VmkLogHandler(logging.Handler):
    """
    setup vmkernel log handler
    """
    ENABLED = False

    def __init__(self, host=None):
        super().__init__()
        self.remote = STAFRemote(host)

    def emit(self, record):
        """
        override emit method in logging.Handler
        """
        message = self.format(record)
        if self.remote and VmkLogHandler.ENABLED:
            try:
                self.remote.ExecuteCmd('/usr/bin/dumper',
                                       '-g \\"LOG: %s\\"' % message, timeout=10)
            except (STAFRemoteProcessError, TimeoutError):
                pass

def setup_logging(cfg_file, logfolder, default_level=logging.INFO, env_key='LOG_CFG'):
    path = cfg_file
    value = os.getenv(env_key, None)
    if value:
        path = value
    if os.path.exists(path):
        # extracting hostname from logfolder
        hostname = logfolder.split(os.path.sep)[3].rsplit('-', 3)[0]
        with open(path, 'rt') as f:
            config = json.load(f)
        for handler, attr in config['handlers'].items():
            if 'filename' in attr:
                attr['filename'] = os.path.join(logfolder, attr['filename'])
            if 'host' in attr:
                attr['host'] = hostname
        logging.config.dictConfig(config)
    else:
        logging.basicConfig(level=default_level)


def create_log_folder(args, datestamp, timestamp, test_index=0):
    """
    Create log on the local host. This code need to know the version
    on the server that it running. However, it should not use STAF
    remote because staf might not get initialed yet
    @param args: system arguments
    @param datestamp: current date stamp
    @param timestamp: current time stamp
    @param test_index: optional param for future use
    @return: location folder of the master log
    """
    hostname = args['hosts'][0]
    testid = '%d' % time.time()
    driver = 'driver'
    vnic = 'vnic'
    #vnic = args['vnic']
    loglocation = args['log_location']
    buff = ''
    try:
        user, psw = get_credentials()
        with ConnectServ(hostname, user, psw, 'paramiko') as s:
            buff = s.send('verion -v')
        buildNo = buff.split('-')[1].strip()
    except IndexError:
        raise EnvironmentError('Return string is not expected %s' % buff)
    except (ConnectServError, TimeoutError):
        # this happens when host is unreachable.
        if ping(hostname):
            raise EnvironmentError('Host is pingable but not able to connect remote connect')
        else:
            raise ParamError('%s is unreachable' % hostname)

    folder = os.path.join(loglocation, datestamp,
                          '%s-%s-%s-%s' % (hostname, driver, vnic, buildNo),
                          '%s-%s' % (testid, timestamp))
    if not os.access(folder, os.F_OK):
        os.makedirs(folder)
    return folder
